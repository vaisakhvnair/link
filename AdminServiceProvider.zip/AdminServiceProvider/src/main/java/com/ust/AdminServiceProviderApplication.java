package com.ust;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.ust"})
public class AdminServiceProviderApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdminServiceProviderApplication.class, args);
	}

}
