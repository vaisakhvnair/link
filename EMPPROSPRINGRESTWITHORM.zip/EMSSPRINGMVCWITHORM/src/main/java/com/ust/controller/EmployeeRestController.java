package com.ust.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.model.Employee;
import com.ust.service.IEmployeeService;

@RestController
@RequestMapping("/erc")
public class EmployeeRestController {

	@Autowired
	IEmployeeService empServiceObj;
	
	@PostMapping("/add")
	public String addEmployee(@RequestBody Employee emp) {
	
		int id= empServiceObj.save(emp);//storing record into emp_tab table
	
		return "employee Id "+id+" Record InsertedSuccessfully..!";
		
	}
	
	@PutMapping("/update")
	public String updateEmployee(@RequestBody Employee emp) {
		String msg=null;
          Employee euobj=empServiceObj.getEmployeeById(emp.getEmpId());//Based on id record exists its will Employee Object or return null
          if(euobj!=null) {
        	  empServiceObj.update(emp);
        	  msg= "Employee REcord "+euobj.getEmpId()+" updated Successfully ";
          }else {
        	  msg="Employee Record Based On Id Doesnot Exist";
          }
		
          return msg;
	}
	
	@DeleteMapping("/delete/{id}")
	public String deleteEmployee(@PathVariable int id) {
		String msg=null;
          Employee euobj=empServiceObj.getEmployeeById(id);//Based on id record exists its will Employee Object or return null
          if(euobj!=null) {
        	  empServiceObj.delete(id);
        	  msg= "Employee REcord "+euobj.getEmpId()+" Deleted Successfully ";
          }else {
        	  msg="Employee Record Based On Id Doesnot Exist";
          }
		
          return msg;
	}
	
	@GetMapping("/list")
	public ResponseEntity<List<Employee>> listAllEmployeeRecords(){ 
		List<Employee> lieobj=empServiceObj.getAllEmployees();
		return new ResponseEntity<List<Employee>>(lieobj,HttpStatus.OK);
	}
	
	
	
}
