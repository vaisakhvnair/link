package com.training.ui;

import java.util.List;
import java.util.Scanner;

import com.training.bean.Product;
import com.training.dao.ProductDao;
import com.training.dao.ProductDaoImpl;

public class Main {

	public static void main(String[] args) {
		
		ProductDao pdao = new ProductDaoImpl();
			
		Scanner scobj = new Scanner(System.in);
		
		do {
			
	      System.out.println("1. InsertProductDetails");
		  System.out.println("2. RetrieveProductDetails");
		  System.out.println("3. Exit");
		  System.out.println(" ");
		  System.out.println("Enter The Choice : ");
		  int ch=scobj.nextInt();
		  
		  switch(ch) {
		   
		  case 1 :  System.out.println("Enter The ProductID : ");
		             int pid = scobj.nextInt();
		            
		            System.out.println("Enter The ProductName : ");
		            String pn =scobj.next();
		            
		            System.out.println("Enter The ProductPrice : ");
		            float pr =scobj.nextFloat();
		            
		            Product pobj = new Product(pid,pn,pr);
		            
		            int iobj =pdao.insertProduct(pobj);
		            
		            if(iobj>0) {
		            	System.out.println("Product Record Is Inserted .");
		            }else {
		            	System.out.println("Product Record Is Not Inserted");
		            }
		            
			  		break;
			
		  case 2 : System.out.println("Product Details are : ");
		            
		           List<Product> liObj= pdao.listProductDetails();
		           
		           //using java8 foreEach 
		           
		           liObj.forEach(p ->System.out.println(p.getPid()+" "+p.getPname()+" "+p.getPrice()));
		            
			  	   break;
		  case 3 : System.out.println("Exited From The Operation ");
	               System.exit(0);
	               break;
	      
	      default : System.out.println("Invalid Choice ");
	      
		  }       
		  		  
		}while(true);
		
		
	}
}
