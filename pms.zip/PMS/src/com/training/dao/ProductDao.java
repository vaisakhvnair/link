package com.training.dao;

import java.util.List;

import com.training.bean.Product;

public interface ProductDao {

	int insertProduct(Product p);
	List<Product> listProductDetails();
	
}
