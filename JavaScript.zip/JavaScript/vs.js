 var a; //declared but not initlaized  --->output undefined
 var b="hello" ;  //declared and initaized
 var c=40

 document.writeln("Variables values are : <br>")
 document.writeln(a+" "+b+" "+c);
