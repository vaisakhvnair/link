function display(){

document.writeln("welcome to javascript using function");	 
}

//function with parameter

function addition(a,b){
 var z= a+b;
 document.writeln("<br> sum of two numbers is : "+z);
}

//function with return type we can return the value using return keyword

function sum(x,y){
   return x+y;
}

//function with expression without parameter

var methodOne= function(){
  document.writeln("<br> we are in methodOne");  //here methodOne() will act as functionName
}

//function with expression with parameters
var methodTwo= function(x,y){
	var z=x+y
  document.writeln("<br> we are in methodTwo "+z);  //here methodTwo(10,30) will act as functionName
}