var chair = {
             "color":"blue",   //  object properties key:value
             "shape":"square",
              "material":"plastic",
              movieable:function(){    //action or behaviour
              	document.write("Chair is movieable");
              }

            }



var stud = new Object() ;   //by creating instance of object
stud.sid=1001
stud.sname="raju"
stud.address="chennai"