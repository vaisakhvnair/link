function usingName(){

var rdName = document.getElementsByName("r1");

document.writeln(rdName)

}