function getloginDetails() {
    
    var un= document.getElementById("i1").value;
    var pwd= document.getElementById("i2").value;
    if(un=="admin" && pwd=="admin")
        return true;
    else
        return false;

}