package com.ust.runner;

import org.springframework.boot.CommandLineRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class AdminServiceConsumer implements CommandLineRunner{

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		RestTemplate rt = new RestTemplate();
		
		//consuming the AdminServiceProvider (showMsg())
		String url="http://localhost:2019/provider/show";
		
       ResponseEntity<String> rset= rt.getForEntity(url,String.class);
		
		System.out.println(rset.getBody());
		System.out.println(rset.getStatusCode());
		
	}

}
